import React from 'react';
import {render} from 'react-dom';
import renderHTML from 'react-render-html';
import $ from 'jquery'; 
class App extends React.Component {
	
	componentDidMount() {
		$.getJSON("http://52.88.26.79:7000/?type=json&w=10&h=10",function(data){
			console.log(data)
			$.each(data, function(i, obj) {
				$.each(obj, function(j, obj1){
					if(obj1 == " "){
						$(".lab").append(" ");
					}else{
						$(".lab").append( obj1);
					}
				});
				$(".lab").append( "<p/>");
			});
			
		});
	}
	clickArriba () {
		var laberinto = $(".lab").text();
		var pos = laberinto.indexOf("p");
		if(laberinto.substring(pos-31,pos-30) != "-" && laberinto.substring(pos-31,pos-30) != "+"){
			laberinto = laberinto.replace("p"," ");
			var antes = laberinto.substring(0,pos-31);
			var despues = "p" + laberinto.substring(pos-31+1, laberinto.length);
			var cadenaFinal = antes+despues;
			$(".lab").empty();
			var i;
			for(i=0; i<651; i=i+31){
				$(".lab").append(cadenaFinal.substring(i,i+31));
				$(".lab").append("<p/>");
			}
		}else{
			alert("PARED");
		}
	}
	clickAbajo () {
		var laberinto = $(".lab").text();
		var pos = laberinto.indexOf("p");
		if(laberinto.substring(pos+31,pos+32) != "-" && laberinto.substring(pos+31,pos+32) != "+"){
			if(laberinto.substring(pos+31,pos+32) == "g"){
				alert("GANASTE");
			}
			laberinto = laberinto.replace("p"," ");
			var antes = laberinto.substring(0,pos+31);
			var despues = "p" + laberinto.substring(pos+31+1, laberinto.length);
			var cadenaFinal = antes+despues;
			$(".lab").empty();
			var i;
			for(i=0; i<651; i=i+31){
				$(".lab").append(cadenaFinal.substring(i,i+31));
				$(".lab").append("<p/>");
			}
		}else{
			alert("PARED");
		}
	}
	clickDerecha () {
		var laberinto = $(".lab").text();
		var pos = laberinto.indexOf("p");
		if(laberinto.substring(pos+1,pos+2) != "|" && laberinto.substring(pos+1,pos+2) != "+" && laberinto.substring(pos+1,pos+2) != "-"){
			if(laberinto.substring(pos+1,pos+2) == "g"){
				alert("GANASTE");
			}
			var antes = laberinto.substring(0,pos)+(" ");
			var despues = "p" + laberinto.substring(pos+2, laberinto.length);
			var cadenaFinal = antes+despues;
			$(".lab").empty();
			var i;
			for(i=0; i<651; i=i+31){
				$(".lab").append(cadenaFinal.substring(i,i+31));
				$(".lab").append("<p/>");
			}
		}else{
			alert("PARED");
		}
	}
	clickIzquierda () {
		var laberinto = $(".lab").text();
		var pos = laberinto.indexOf("p");
		if(laberinto.substring(pos-1,pos) != "|" && laberinto.substring(pos-1,pos) != "+" && laberinto.substring(pos-1,pos) != "-"){
			var antes = laberinto.substring(0,pos-1)+("p");
			var despues = " " + laberinto.substring(pos+1, laberinto.length);
			var cadenaFinal = antes+despues;
			$(".lab").empty();
			var i;
			for(i=0; i<651; i=i+31){
				$(".lab").append(cadenaFinal.substring(i,i+31));
				$(".lab").append("<p/>");
			}
		}else{
			alert("PARED");
		}
	}

	render() {
		return (
			<div>
				Controles:
				<button onClick={this.clickArriba}>Arriba</button>
				<button onClick={this.clickAbajo}>Abajo</button>
				<button onClick={this.clickIzquierda}>Izquierda</button>
				<button onClick={this.clickDerecha}>Derecha</button>
			</div>
		)
	}
	

}

render(<App/>, document.getElementById('app'));